create definer = root@localhost view affichage as
select `st2eedb`.`info_intern`.`lastname`      AS `lastname`,
       `st2eedb`.`info_intern`.`address`       AS `address`,
       `st2eedb`.`info_intern`.`intern_group`  AS `intern_group`,
       `st2eedb`.`mission`.`eval_sheet_id`     AS `eval_sheet`,
       `st2eedb`.`mission`.`visit_sheet_id`    AS `visit_sheet`,
       `st2eedb`.`mission`.`report_title`      AS `report_title`,
       `st2eedb`.`mission`.`soutenance`        AS `soutenance`,
       `st2eedb`.`mission`.`start_mission`     AS `start_mission`,
       `st2eedb`.`mission`.`end_mission`       AS `end_mission`,
       `st2eedb`.`eval_sheet`.`grade_tech`     AS `grade_tech`,
       `st2eedb`.`eval_sheet`.`grade_com`      AS `grade_com`,
       `st2eedb`.`visit_sheet`.`visit_planned` AS `visit_planned`,
       `st2eedb`.`visit_sheet`.`visit_done`    AS `visit_done`
from (((((`st2eedb`.`intern` left join `st2eedb`.`teacher` on ((`st2eedb`.`teacher`.`id` = `st2eedb`.`intern`.`id`))) left join `st2eedb`.`info_intern` on ((`st2eedb`.`info_intern`.`id` = `st2eedb`.`intern`.`id`))) left join `st2eedb`.`mission` on ((`st2eedb`.`mission`.`id` = `st2eedb`.`intern`.`id`))) left join `st2eedb`.`eval_sheet` on ((`st2eedb`.`eval_sheet`.`id` = `st2eedb`.`mission`.`id`)))
         left join `st2eedb`.`visit_sheet` on ((`st2eedb`.`visit_sheet`.`id` = `st2eedb`.`mission`.`id`)))
where (`st2eedb`.`teacher`.`id` = 1);

